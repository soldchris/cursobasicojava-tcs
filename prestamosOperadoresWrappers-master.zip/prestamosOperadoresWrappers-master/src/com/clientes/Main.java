package com.clientes;

import com.clases.*;
import java.util.*;

public class Main {

    public static void main(String[] args) {

        BeneficiosCovid19 beneficio;
        List<BeneficiosCovid19> beneficios = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        String entrada = "SI";
        int error= 0;
        String dato = null;
        String nombre = null;
        Float valor = null;

        while (entrada.equals("SI")){

            if((nombre == null || error == 1 )){
                System.out.println(Mensajes.NOMBRESUBSIDIO);
                dato = in.nextLine();
                if(dato == null || dato.trim().equals("")){
                    error = 1;
                }else{
                    nombre = dato;
                    error = 0;
                }
            }

            if(error == 2 || (valor == null  && nombre != null)) {
                System.out.println(Mensajes.VALORSUBSIDIO);
                dato = in.nextLine();
                    if(dato == null || dato.trim().equals("")){
                        error = 2;
                    }else if(isNumeric(dato)){
                        valor = Float.parseFloat(dato);
                        error = 0;
                     }else {
                        error = 2;
                        System.out.println(Mensajes.NONUMERICO);
                    }
            }

            if ( error == 0){
                int ind = 1;
                beneficio = new BeneficiosCovid19(nombre, valor);
                beneficios.add(beneficio);
                while (ind == 1){
                    System.out.println(Mensajes.PREGUNTA);
                    entrada = in.nextLine().toUpperCase();
                    if (entrada.equals("SI") || entrada.equals("NO")){
                        ind = 0;
                        nombre = null;
                        valor = null;
                    }else{
                        System.out.println(Mensajes.ERROR);
                    }
                }
            }
        }

        System.out.println(Mensajes.MARCO);
        System.out.println(Mensajes.MEJORBENEFICIO + getMejorbeneficios(beneficios));
        System.out.println(Mensajes.MARCO);
        System.out.println(Mensajes.BENEFICIOS);
        System.out.println(Mensajes.MARCO);
        listar(beneficios);
        in.close();

    }


    public static Float getMejorbeneficios(List<BeneficiosCovid19> beneficios){
        float mayorValor = 0;

        for (int i= 0; i <beneficios.size();i++){
            if(beneficios.get(i).getValorSubsidio() > mayorValor){
                mayorValor = beneficios.get(i).getValorSubsidio();
            }
        }
        return Float.valueOf(mayorValor);
    }

    public static void listar(List<BeneficiosCovid19> beneficios){
        for(BeneficiosCovid19 bene : beneficios){
            System.out.println(bene);
        }
        System.out.println(Mensajes.MARCO);
    }

    public static boolean isNumeric(String value) {
        try{
            Double.parseDouble(value);
            return true;
        }catch (NumberFormatException nfe){
            return false;
        }

    }
}
