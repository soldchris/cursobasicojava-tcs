package com.clases;

public class Mensajes {
    public final static String NONUMERICO = "El dato ingresado no es numerico";
    public final static String NOMBRESUBSIDIO = "Digite a continuación el nombre del subsidio: ";
    public final static String VALORSUBSIDIO = "Digite a continuación el valor del subsidio: ";
    public final static String PREGUNTA = "Desea cargar otro beneficio ? (SI/NO)";
    public final static String MARCO = "***************************************************++++++++++++++++++++++++++++***";
    public final static String BENEFICIOS ="Lista de todos los beneficios cargados al sistema a continuación: ";
    public final static String MEJORBENEFICIO ="Valor del mejor beneficio: ";
    public final static String ERROR ="Error! - solo se aceptan las palabras -> SI / NO ";
}
