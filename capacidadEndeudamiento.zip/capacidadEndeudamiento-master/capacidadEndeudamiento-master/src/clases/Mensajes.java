package clases;

public class Mensajes {
    public final static String bienvenida = "Si desea abortar el programa puede hacerlo con la palabra SALIR";
    public final static String ingresos = "Digite sus ingresos mensuales: ";
    public final static String noNumerico = "El dato ingresado no es numerico";
    public final static String fijos = "Ingrese sus gastos fijos";
    public final static String variables = "Ingrese sus gastos variables";
    public final static String iniciar = "Desea volver a realizar otra petición ? (SI/NO)";
    public final static String resultado = "Capacidad de Endeudamiento: ";
}
