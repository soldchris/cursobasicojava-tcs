package com.company;

import clases.CapacidadEndedudamiento;
import clases.Mensajes;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        CapacidadEndedudamiento capacidad = new CapacidadEndedudamiento();
        new Mensajes();

        int ingMesuales =0;
        int gastosFijos = 0;
        int gastosVaiables = 0;
        int error = 0;
        String dato = null;

        System.out.println(Mensajes.bienvenida);

        String entrada = "SI";
        while (entrada.equals("SI")) {

            if ((entrada.equals("SI") && (error == 0)) || error == 1 ){
                System.out.println(Mensajes.ingresos);
                dato = in.nextLine().toUpperCase();
                if(dato.equals("SALIR")){
                    break;
                }

                if(isNumeric(dato)){
                    ingMesuales = Integer.parseInt(dato);
                    error = 0;
                }else {
                    error = 1;
                    System.out.println(Mensajes.noNumerico);
                }

            }

             if(error == 0 || error == 2){
                System.out.println(Mensajes.fijos);
                dato = in.nextLine().toUpperCase();
                 if(dato.equals("SALIR")){
                     break;
                 }

                 if(isNumeric(dato)){
                     gastosFijos = Integer.parseInt(dato);
                     error = 0;
                 }else {
                     error = 2;
                     System.out.println(Mensajes.noNumerico);
                 }
             }

            if(error == 0 || error == 3){
                System.out.println(Mensajes.variables);
                dato = in.nextLine().toUpperCase();
                if(dato.equals("SALIR")){
                    break;
                }

                if(isNumeric(dato)){
                    gastosVaiables = Integer.parseInt(dato);
                    error = 0;
                }else {
                    error = 3;
                    System.out.println(Mensajes.noNumerico);
                }
            }

            if(error == 0){
                capacidad.setIngresosTotales(ingMesuales);
                capacidad.setGastosFijos(gastosFijos);
                capacidad.setGastoVaribales(gastosVaiables);
                System.out.println(Mensajes.resultado + capacidad.getCapacidadEndeudamiento());
                System.out.println(capacidad);
                System.out.println(Mensajes.iniciar);
                entrada = in.nextLine().toUpperCase();
            }

        }

        if(entrada.equals("NO") || dato.equals("SALIR")){
            in.close();
        }
    }

    public static boolean isNumeric(String value) {
        try{
            Double.parseDouble(value);
            return true;
        }catch (NumberFormatException nfe){
            return false;
        }

    }

}
