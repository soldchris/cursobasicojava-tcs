package com.clientes;

import com.clases.*;

import javax.swing.*;
import java.sql.Connection;
import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {
        Integer opMenu = -1;
        ArrayList<Clientes>  vectorClientes = new ArrayList<Clientes>();
        ArrayList<Producto>vectorProductos = new ArrayList<Producto>();
        String menu =
                        "         * 1 Agregar cliente\n" +
                        "         * 2 Editar cliente\n" +
                        "         * 3 Eliminar cliente\n" +
                        "         * 4 Agregar productos\n" +
                        "         * 5 Consultar clientes con documento y tipo de documento \n" +
                        "         * 0 salir de la aplicacion";
        do {
            try{
                opMenu = Integer.parseInt(JOptionPane.showInputDialog(null,menu,"Menú",JOptionPane.INFORMATION_MESSAGE));
                switch (opMenu.toString()) {
                    case "1":
                        vectorClientes.add(Datos.nuevo());
                        break;
                    case "2":
                        Datos.buscar(vectorClientes);
                        break;
                    case "3":
                        Datos.Eliminar(vectorClientes);
                        break;
                    case "4":
                        vectorProductos.add(CargaProducto.nuevo());
                        break;
                    case "5":
                        Datos.consulta(vectorClientes);
                        break;
                    case "0":
                        JOptionPane.showMessageDialog(null,"Muchas gracias por usar nuestra app, hasta luego!",
                                "Hasta luego!!", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,"No ingreso una opción valida en el menú",
                                "Menu", JOptionPane.INFORMATION_MESSAGE);
                        break;
                }
            }catch (Exception e){
                    JOptionPane.showMessageDialog(null,"El valor Ingresado no es Numerico",
                            "Error", JOptionPane.WARNING_MESSAGE);
            }
        } while (!opMenu.toString().equals("0"));
    }
}
