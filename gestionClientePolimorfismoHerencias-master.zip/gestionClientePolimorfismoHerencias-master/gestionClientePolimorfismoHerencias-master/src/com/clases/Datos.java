package com.clases;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class Datos {

    public static Clientes nuevo(){
        String resp ="SI";
        ArrayList<Producto>vectorProductos = new ArrayList<Producto>();
        Clientes cliente = new Clientes();
        cliente.setNombre(JOptionPane.showInputDialog(null,"Nombre"));
        cliente.setApellido(JOptionPane.showInputDialog(null,"Apellido"));
        cliente.setTipoCedula(JOptionPane.showInputDialog(null,"Tipo de Cédula"));
        cliente.setCedula(JOptionPane.showInputDialog(null,"Número de Cédula"));
        cliente.setTelefono(JOptionPane.showInputDialog(null,"Telefono"));
        cliente.setCelular(JOptionPane.showInputDialog(null,"Celular"));
        cliente.setDireccion(JOptionPane.showInputDialog(null,"Dirección"));
        while (resp.equals("SI")){
            vectorProductos.add(CargaProducto.nuevo());
            resp= JOptionPane.showInputDialog(null,"Desea cargar otro Producto (SI/NO)").toUpperCase();
        }
        cliente.setProductos(vectorProductos);
        JOptionPane.showMessageDialog(null,"Cliente nuevo Creado!","Nuevo Cliente",JOptionPane.INFORMATION_MESSAGE);
        return cliente;
    }

    public static void consulta(ArrayList<Clientes> lista){
        boolean existe = false;
        String tipCed = (JOptionPane.showInputDialog(null,"Introduzca el tipo de Cédula",
                "Busqueda", JOptionPane.INFORMATION_MESSAGE));
        String cedula =(JOptionPane.showInputDialog(null,"Introduzca el número de Cédula",
                "Busqueda", JOptionPane.INFORMATION_MESSAGE));
        for (Clientes cli: lista)
            if (tipCed.equals(cli.getTipoCedula()) && cedula.equals(cli.getCedula())){
                JOptionPane.showMessageDialog(null,
                        " * Nombre: " + cli.getNombre() + "\n" +
                                " * Apellido: " + cli.getApellido() + "\n" +
                                " * Tipo de Cédula: " + cli.getTipoCedula() + "\n" +
                                " * Número de Cédula :" + cli.getCedula() + "\n" +
                                " * Número de Teléfono :" + cli.getTelefono() + "\n" +
                                " * Número de Celular :" + cli.getCelular() + "\n" +
                                " * Dirección :" + cli.getDireccion()+ "\n" +
                                " -------- Lista de Productos -------- " +"\n"
                                + cli.getProductos(),
                        "CONSULTA DE CLIENTES",JOptionPane.INFORMATION_MESSAGE);
                existe = true;
                break;
            }
        if (!existe){
                JOptionPane.showMessageDialog(null,"No se encontro el cliente",
                        "Aviso",JOptionPane.WARNING_MESSAGE);
            }
        }

    public static void buscar(ArrayList<Clientes> lista){
        boolean existe = false;
        String tipCe = (JOptionPane.showInputDialog(null,"Introduzca el tipo de Cédula",
                "Editar Cliente", JOptionPane.INFORMATION_MESSAGE));
        String cedu =(JOptionPane.showInputDialog(null,"Introduzca el núemro de Cédula",
                "Editar Cliente", JOptionPane.INFORMATION_MESSAGE));

        for (int i = 0; i < lista.size(); i++) {
            if (tipCe.equals(lista.get(i).getTipoCedula()) && cedu.equals(lista.get(i).getCedula())){
                edicion(lista.get(i));
                existe= true;
            }
        }
        if (!existe){
            JOptionPane.showMessageDialog(null,"Cliente no existe","Modificación de Datos",JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void edicion(Clientes cliente){
        cliente.setNombre(JOptionPane.showInputDialog(
                null,"Nombre del Cliente",cliente.getNombre()));
        cliente.setApellido(JOptionPane.showInputDialog(
                null,"Apellido del Cliente",cliente.getApellido()));
        cliente.setTipoCedula(JOptionPane.showInputDialog(
                null,"Tipo del Cédula",cliente.getTipoCedula()));
        cliente.setCedula(JOptionPane.showInputDialog(
                null,"Cédula del Cliente",cliente.getCedula()));
        cliente.setTelefono(JOptionPane.showInputDialog(
                null,"Telefono del Cliente",cliente.getTelefono()));
        cliente.setCelular(JOptionPane.showInputDialog(
                null,"Celular del Cliente",cliente.getCelular()));
        cliente.setDireccion(JOptionPane.showInputDialog(
                null,"Dirección del Cliente",cliente.getDireccion()));
        JOptionPane.showMessageDialog(null,"Cliente Actualizado","Modificación de Datos",JOptionPane.INFORMATION_MESSAGE);
    }

    public static void Eliminar(ArrayList<Clientes> lista){
        boolean existe = false;
        String tipCe = (JOptionPane.showInputDialog(null,"Introduzca el tipo de Cédula",
                "Elimnar Cliente", JOptionPane.INFORMATION_MESSAGE));
        String cedu =(JOptionPane.showInputDialog(null,"Introduzca el núemro de Cédula",
                "Eliminar Cliente", JOptionPane.INFORMATION_MESSAGE));

        for (int i = 0; i < lista.size(); i++) {
            if (tipCe.equals(lista.get(i).getTipoCedula()) && cedu.equals(lista.get(i).getCedula())){
                lista.remove(i);
                JOptionPane.showMessageDialog(null,"Cliente ha sido eliminado","Modificación de Datos",JOptionPane.INFORMATION_MESSAGE);
                existe = true;
                break;
            }
        }
        if (!existe){
            JOptionPane.showMessageDialog(null,"Cliente no existe","Modificación de Datos",JOptionPane.INFORMATION_MESSAGE);
        }
    }


}
