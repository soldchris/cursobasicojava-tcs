package com.clases;

public class Personas {
    private String cedula;
    private String tipoCedula;
    private String celular;

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTipoCedula() {
        return tipoCedula;
    }

    public void setTipoCedula(String tipoCedula) {
        this.tipoCedula = tipoCedula;
    }

    @Override
    public String toString() {
        return "Personas{" +
                "cedula='" + cedula + '\'' +
                ", tipoCedula='" + tipoCedula + '\'' +
                ", celular='" + celular + '\'' +
                '}';
    }
}
