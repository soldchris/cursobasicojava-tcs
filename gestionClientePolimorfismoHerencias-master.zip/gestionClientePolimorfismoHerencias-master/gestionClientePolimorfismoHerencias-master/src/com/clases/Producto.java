package com.clases;

public class Producto extends Empresas{
    private String nombre;
    private String carateristicas;
    private String idProducto;
    private String condiciones;

    public Producto(){
        getIdProducto();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCarateristicas() {
        return carateristicas;
    }

    public void setCarateristicas(String carateristicas) {
        this.carateristicas = carateristicas;
    }

    public String getIdProducto() {
        this.idProducto = String.valueOf(Math.floor(Math.random()*1000)) ;
        return this.idProducto;
    }


    public String getCondiciones() {
        return condiciones;
    }

    public void setCondiciones(String condiciones) {
        this.condiciones = condiciones;
    }

    @Override
    public String toString() {
        return  " " + "\n"+
                " * Producto: " + nombre + "\n" +
                " * Carateristicas: " + carateristicas + "\n" +
                " * ID Producto: "  + idProducto + "\n" +
                " * Condiciones: " +  condiciones + "\n" +
                " *" + super.toString();
    }

}
