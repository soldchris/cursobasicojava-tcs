package com.clases;

import javax.swing.*;

public class Empresas {
    private String tipDoc;
    private String documento;
    private String representante;

    public String getTipDoc() {
        return tipDoc;
    }

    public void setTipDoc(String tipDoc) {
        this.tipDoc = tipDoc;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getRepresentante() {
        return representante;
    }

    public void setRepresentante(String representante) {
        this.representante = representante;
    }

    @Override
    public String toString() {
        return " Datos de la Empresa " + "\n" +
                " * Tipo de Documento: " + tipDoc + "\n" +
                " * Documento Empresa: " + documento + "\n" +
                " * Representante: " + representante + "\n";
    }
}
