package com.clases;

import javax.swing.*;

public class CargaProducto {

    public static Producto nuevo(){
        Producto producto = new Producto();
        producto.setNombre(JOptionPane.showInputDialog(null,"Nombre del Producto"));
        producto.setCarateristicas(JOptionPane.showInputDialog(null,"Caracteristicas del Producto"));
        producto.setCondiciones(JOptionPane.showInputDialog(null,"Condiciones - Nuevo/Usado"));
        producto.setTipDoc(JOptionPane.showInputDialog(null,"Tipo de Documento de la Empresa"));
        producto.setDocumento(JOptionPane.showInputDialog(null,"Número Documento de la Empresa"));
        producto.setRepresentante(JOptionPane.showInputDialog(null,"Representante de la Empresa"));
        JOptionPane.showMessageDialog(null,"Producto Cargado!","Nuevo Producto",JOptionPane.INFORMATION_MESSAGE);
        return producto;
    }


}
